#include <stdio.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <netdb.h>
#include <netinet/in.h>

#include <string.h>

int main(int argc, char *argv[]) {
   int sockfd, n;
   struct sockaddr_in serv_addr;
   char message[256] = {};
   char received[256] = {};

   /* Create a socket point */
   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if (sockfd < 0) {
      perror("ERROR opening socket");
      exit(1);
   }
   bzero((char *) &serv_addr, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_port = htons(1234);
   serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
   
   /* Now connect to the server */
   if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
      perror("ERROR connecting");
      exit(1);
   }
   
   /* Now ask for a message from the user, this message
      * will be read by server
   */
    while(1) {
        bzero(received,sizeof(received));
        bzero(message,sizeof(message));
        read(sockfd,received,sizeof(received));
        printf("%s", received);
        scanf("%s", message);
        /* Send message to the server */
        write(sockfd, message, sizeof(message));
        
        /* Now read server response */
        if (strcmp(message, "1") == 0) {
            bzero(received, sizeof(received));
            read (sockfd, received, sizeof(received));
            printf("%s", received); // read the input URL address
            bzero(message, sizeof(message));
            scanf("%s", message);
            write(sockfd, message, sizeof(message));
            bzero(received, sizeof(received));
            read(sockfd, received, sizeof(received));
            printf("Address get from domain name: %s\n\n", received);
        }
        else if (strcmp(message, "2") == 0) {
            bzero(received, sizeof(received));
            read(sockfd, received, sizeof(received));
            printf("%s", received); // read the input studewnt ID
            bzero(message, sizeof(message));
            scanf("%s", message);
            write(sockfd, message, sizeof(message));
            bzero(received, sizeof(received));
            read(sockfd, received, sizeof(received));
            printf("Email get from the server : %s\n\n", received);
        }
        else if (strcmp(message, "3") == 0) { // quit
            break;
        }
        else { // handle wrong input
            bzero(received, sizeof(received));
            n = read(sockfd, received, sizeof(received));
            printf("%s\n\n", received); // print "the command shound be 1 to 3"
        }
    }
    close(sockfd);                 
    return 0;
}