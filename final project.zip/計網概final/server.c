#include <stdio.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <netdb.h>
#include <netinet/in.h>

#include <string.h>

typedef struct student {
    char id[256];
    char email[256];
}student;

int main(int argc, char *argv[] ) {
    int sockfd, newsockfd, clilen;
    char buffer[256] = {};
    char message[256] ={};
    struct sockaddr_in serv_addr, cli_addr;
    int n;
    //read the query
    FILE *fp = NULL;
    int idx = 0;
    student table[105];
    fp = fopen("query.txt","r");
    while(fscanf(fp, "%s%s", table[idx].id, table[idx].email) != EOF) {
        idx++;
    }
    
    /* create socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0) {
        perror("ERROR opening socket");
        exit(1);
    }

    /* Initialize socket structure */
    bzero((char *) &serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(1234);
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    printf("Waiting for connection...\n");

    /* Now bind the host address using bind() call.*/
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        perror("ERROR on binding");
        exit(1);
    }
        
    /* Now start listening for the clients, here process will
        * go in sleep mode and will wait for the incoming connection
    */
    struct hostent *host;
    while(1) {
    listen(sockfd,10); // start listening
    clilen = sizeof(cli_addr);
        /* Accept actual connection from the client */
        newsockfd = accept(sockfd, (struct sockaddr* ) &cli_addr, (socklen_t *) &clilen);
        if (newsockfd < 0) {
            perror("ERROR on accept");
            exit(1);
        }
    /* If connection is established then start communicating */
        while(1) {
            bzero(message,sizeof(message));
            strcpy(message, "What's your requirement? 1.DNS 2.QUERY 3.QUIT : "); // ask for requirement
            write(newsockfd, message, sizeof(message));
            bzero(buffer, sizeof(buffer));
            n = read(newsockfd,buffer, sizeof(buffer));

            if (n < 0) {
                perror("ERROR reading from socket");
                exit(1);
            }
            if (strcmp(buffer, "1") == 0) {
                bzero(message,sizeof(message));
                strcpy(message,"Input URL address : "); // ask for URL address
                write(newsockfd, message, sizeof(message));
                bzero(buffer, sizeof(buffer)); 
                read(newsockfd, buffer, sizeof(buffer));
                host = gethostbyname(buffer);
                bzero(message,sizeof(message));
                if (host == NULL) {
                    strcpy(message, "There's no such URL address.");
                    write(newsockfd, message, sizeof(message));
                }
                else {
                    strcpy(message, inet_ntoa(*((struct in_addr*)host->h_addr)));
                    write(newsockfd, message, sizeof(message));
                }
            }
            else if (strcmp(buffer, "2") == 0) {
                bzero(message,sizeof(message));
                int found = 0;
                strcpy(message, "Input student ID: "); // ask for student ID
                write(newsockfd, message, sizeof(message));
                bzero(buffer, sizeof(buffer));
                read(newsockfd, buffer, sizeof(buffer));
                bzero(message,sizeof(message));
                for (int i = 0; i < idx; i++) { // look for the same student ID in the query
                    if ((strcmp(buffer, table[i].id) == 0) && found != 1){
                        found = 1;
                        strcpy(message, table[i].email);
                    }
                }
                if (found != 1) strcpy(message, "NO such student ID");
                write(newsockfd, message, sizeof(message));
            }
            else if (strcmp(buffer, "3") == 0) {
                printf("Connection Ends.\n");
                break;
            }
            else {
                strcpy(message, "Wrong command, the command should be 1 to 3"); // handle wrong input
                write(newsockfd, message, sizeof(message));
            }
            /* Write a response to the client */
            if (n < 0) {
                perror("ERROR writing to socket");
                exit(1);
            }  
        }   
    }
    return 0;
}